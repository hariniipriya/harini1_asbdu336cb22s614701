
list1=['abcd',147,2.43,'tom']
list1.remove('tom')
print(list1)