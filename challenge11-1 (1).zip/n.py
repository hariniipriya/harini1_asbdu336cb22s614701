s="python programming"
print(s.isspace())
s=" "
print(s.isspace())
